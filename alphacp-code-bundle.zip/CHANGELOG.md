# CHANGELOG

All notable changes to AlphaCP are documented here.
Format: [Keep a Changelog](https://keepachangelog.com/) · Versioning: SemVer.

## [Unreleased]
### Fixed / Changed
- **Step 2B-1 INSTALLED ON dev-srv1 (29 Sep 00:02)** 🎉 — panel live: `https://13.207.123.177:8090`
  (Laravel 13.33.0, nginx+php-fpm, user `alphacp`), Apache sites untouched (HTTP 200 verified).
  Credentials: `admin` + password in `/root/.alphacp-admin-credentials` (first login par change forced).
  Installer jo chala: https://paste.rs/0r1Mi (v0.3.3).
- **panel-doctor.sh v1.6 (29 Sep)** — https://paste.rs/G72oK: **ASLI root cause mil gaya —
  systemd `ProtectSystem=full` php-fpm ke liye /usr (aur isliye /usr/local/alphacp) read-only
  kar deta hai → web par har request 500**, jabki CLI sab likh leta hai. v1.6 me: Step 2b
  sandbox audit + Step 2c nsenter write-test (proof) + Step 5a ReadWritePaths drop-in auto-fix.
  Container me server-jaisi condition bana kar PROVEN: 500 → doctor → 200 → PANEL READY.
- **panel-doctor.sh v1.5 (29 Sep)** — https://paste.rs/pnV7U: poori fix-chain (runtime saaf + perms →
  php-fpm audit: <8.3 pools disable / missing pool create → hit → CLI+HTTP asli error → auto-heal:
  DB 3-jagah sync, sessions migrate, LOG_CHANNEL=stderr fallback → cache rebuild → VERDICT).
  Start-me **v1.5 banner** + verdict version-tag (purani command se farq pata chale).
  500-state (stale 7.4 pool + galat DB password) par locally verify: heal → 200 → login ✅
- **panel-doctor.sh v1.4 (29 Sep)** — https://paste.rs/LxbJT: **root cause of the 500 = stale `php7.4` alphacp
  pool grabbing `/run/php/alphacp-fpm.sock`** (panel ko PHP 8.3+ chahiye). Doctor ab `/etc/php/*/fpm/pool.d/alphacp.conf`
  dhoondh kar <8.3 wale pools disable karta hai, unke fpm stop karta hai, 8.3+ fpm restart karke socket dobara
  banata hai, aur socket owner print karta hai. Locally fake 7.4 pool bana kar verify kiya → 200 ✅
- **panel-doctor.sh v1.3 (29 Sep)** — https://paste.rs/vbVD9: heal + php-fpm restart + 10× hit +
  CLI & HTTP-level asli error (debug temporarily ON → restore) + **auto-heal** (DB password teeno jagah sync /
  sessions table migrate). 3 scenario me verified: healthy → READY, root-owned logs → 200, DB mismatch → 200.
- **panel-doctor.sh v1.1 (29 Sep)** — https://paste.rs/wsPmr: permission heal + php-fpm restart + panel
  hit + (agar 500) Laravel ko `alphacp` user/php-fpm ini ke saath boot karke **asli exception** print +
  `laravel-*.log` & nginx tail + saaf VERDICT. Do scenarios me verify: root-owned logs (heal → 200) aur
  bad DB password (`Access denied for user 'alphacp'@'localhost'` sahi detect hua).
- **HTTP 500 fix (29 Sep, v0.3.6)** — https://paste.rs/EPW3b: saari artisan commands ab panel user (`alphacp`) ke
  roop me (`runuser`) chalti hain, isliye `storage/logs/laravel.log` root-owned nahi banta; aakhir me
  storage/bootstrap-cache ka chown + chmod (0770/0660). Locally 500-state reproduce karke verify kiya.
- **Single-shot installer (29 Sep, v0.3.5)** — https://paste.rs/vVdFC: `cd /` (getcwd spam band), /etc/hosts fix,
  root-check pehle, deterministic admin password, APP_KEY preserve, 60s verify + auto service restart,
  fail par poora diagnostics dump, aur aakhir me `VERDICT: PANEL READY ✅/❌` line.
- **Re-run safety (29 Sep, v0.3.4)** — installer https://paste.rs/VD0Px: APP_KEY aur admin password
  `/usr/local/alphacp/var/` me preserve hote hain (pehle re-run par `.env` wipe hone se password
  summary me chhup jata tha, aur 2FA secrets APP_KEY rotate hone se toot jate). `getcwd` noise fix.
- **Step 2B deploy path (28 Sep, working)** — panel ab `installer/step2b-setup.sh` (v0.3.3, https://paste.rs/0r1Mi)
  se install hota hai; `docs/runbooks/step-2b-panel-deploy.md` runbook me pura detail.
  - Panel = **Laravel 13.33.0** (v0.3.0 panel bundle, sha256 `c6712916…`): login, dashboard (live paneld
    data), **User Manager, RBAC middleware, 2FA (TOTP), audit log, security headers**, 9 PHPUnit test files.
  - Setup script: code chunks (3 × paste.rs) → checksum → extract (`--strip-components=1`) → composer →
    DB/grants → `panel.env` + `.env` → migrate/seed → `alphacp:admin-password` → php-fpm pool (user
    `alphacp`) → self-signed TLS + nginx vhost **:8090** → verify HTTP 200.
  - Re-run safe: admin password rotate **nahi** hota (chahiye to `ADMIN_PASSWORD=…` do).
  - Old `installer/panel-install.sh` (Laravel 11) **obsolete** — composer 2.10.3 security advisories
    ne Laravel 11 ke saare versions block kar diye ("could not be resolved to an installable set").
  - nginx 1.24 ke liye `http2 on;` auto-strip; nginx default site (port 80, Apache ka) auto-disable.
  - **PHP auto-detect (v0.3.3)**: `ACP_PHP_PRIMARY` par bharosa nahi — har installed PHP se
    `artisan --version` probe hota hai, extensions apt se bhar jaate hain, aur fail par asli artisan
    error print hota hai (pehle sirf "log dekho" tha). Verified: fake broken `php8.3` ke saath bhi
    script sahi PHP chunti hai aur install pass hota hai.

### Added
- **Step 2B-1 (Panel UI: login + dashboard on port 8090)** — `installer/panel-install.sh` v0.3.0:
  - `panel/` — Laravel 11 app (ADR-0001) served by nginx + php-fpm on **8090** (self-signed TLS
    for now), running as `www-data` — never root (ADR-0002). Apache keeps 80/443 for customer sites.
  - **Login** — session auth + CSRF, brute-force throttle (5 fails/15 min → 15 min block, all
    attempts recorded in `login_attempts`), audit rows for success/failure/logout.
  - **Dashboard** — live memory/disk/load, service table, task-queue card, module tiles for all
    9 cPanel sections, recent audit activity. Data comes from `paneld` via the task queue
    (`system.info`, `service.status` with `requested_src=panel`).
  - **Credentials rule** — the panel reads `/usr/local/alphacp/etc/database.env` at boot
    (`app/Support/AcpEnv.php`); it never keeps a second copy of the DB password.
  - `db/migrations/0002_panel_core.sql` — users, roles, permissions, role_permissions,
    user_permissions, login_attempts + seeded roles (superadmin/admin/reseller/support/user).
  - `php artisan alphacp:create-admin` — bootstrap admin creation (random password printed once).
  - Security headers middleware (CSP, X-Frame-Options, nosniff, Referrer-Policy).
  - `tools/build-panel-installer.py` — packs panel + migrations into a checksum-protected installer.
  - Installer: https://paste.rs/p4iDj (v0.3.0, script sha256 `47bbd854f34b2b6c…`, 69 KB) — full 7-phase run verified; payload builds are reproducible (gzip mtime=0).
  - Installer bugfixes found by testing: runtime dirs created before composer, full payload sync
    (dotfiles included), `.env` guard + 0640, and **`set -e` stays active inside `main()`** in both
    installers (silent-failure bug).

- **Step 1 (Base server stack)** — one-click installer v0.1.1 (`installer/install.sh`):
  Apache(mpm_event)+PHP-FPM 7.4–8.4, Nginx (installed, stopped), MariaDB (loopback-hardened),
  Redis (local-only), BIND9, mail/FTP packages (stopped by design), fail2ban, UFW full port map,
  disk quotas + 2 GB swap, Composer, Node 20, and the `alphacp` CLI v0.
  Re-run-safe (phases + state file), dry-run mode, verify report.
  - Fixes after install #1: nginx-vs-apache port-80 race (pre-clean + final health check),
    correct ext4 quota fstab options, MySQL loopback-only verify logic, ajax-free diagnostics.
- **Step 2A (paneld agent + task queue)** — `installer/step2-install.sh` v0.2.0:
  - `agent/` — root task agent `paneld` (PHP 8.3, zero dependencies, systemd `paneld.service`):
    allowlist registry (`config/tasks.php`), JSON-schema payload validation (hand-rolled, fails
    closed), array-exec only command runner with binary allowlist + timeouts, `PathGuard`
    (canonicalised roots, `..`/symlink escapes blocked), immutable audit rows, per-task logs,
    crash-safe stale-claim recovery, `SELECT ... FOR UPDATE SKIP LOCKED` claiming.
  - tasks: `agent.ping`, `system.info`, `service.status` (readonly).
  - `db/migrations/0001_core.sql` — servers, settings, system_events, tasks, task_logs,
    audit_logs, updates_history, schema_migrations.
  - `cli/alphacp` v0.2.0 — `status`, `doctor [--fix]`, `task types|run|list|show`,
    `agent status|selftest|restart|recover`, `logs`.
  - `agent/tests/run-tests.php` — 16 unit tests (JsonSchema, PathGuard, command allowlist,
    registry integrity), no DB required.
  - `tools/build-step2-installer.py` — packs agent+cli+db into a checksum-protected
    one-file installer; repo stays the source of truth.
- **Step 0 (Blueprint)** — complete design foundation:
  - `AI_CONTEXT.md` (session context for any AI/dev) + `AGENTS.md` (AI rules)
  - `docs/00-requirements-freeze.md` — v1 scope lock, personas, compat promises, limit keys
  - `docs/01-architecture.md` — system architecture, agent design, data flows
  - `docs/02-database-schema.sql` — 55-table design spec (step-tagged)
  - `docs/03-security-matrix.md` — RBAC matrix, task safety classes, audit rules
  - `docs/04-coding-standards.md` — PHP/TS rules, module discipline, AI collaboration rules
  - `docs/05-license-system.md` — commercial license system + license server design
  - `docs/06-installer-updater.md` — one-click install/update/rollback design
  - `docs/07-decision-log.md` — 10 ADRs (stack, agent, license, updater, module pattern)
  - `docs/08-module-blueprint.md` — mandatory module shape + extension checklists
  - `ROADMAP.md`, repo skeletons (`panel/`, `agent/`, `installer/`, `license-server/`)

## [0.0.0] — 2026-09-28
### Added
- Project inception: 16-step roadmap, master plan, dev server provisioned
  (AWS Lightsail `dev-srv1`, Ubuntu 24.04, 4 GB, Mumbai).
