<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\BackupConfig;
use App\Models\Role;
use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class BackupConfigTest extends TestCase
{
    use RefreshDatabase;

    private function userWithRole(string $roleName): User
    {
        $this->seed(RolesAndPermissionsSeeder::class);
        $role = Role::query()->where('name', $roleName)->firstOrFail();

        return User::query()->create([
            'username'      => 'u_' . $roleName,
            'password_hash' => Hash::make('CorrectHorse1'),
            'role_id'       => $role->id,
            'status'        => 'active',
        ]);
    }

    private function asPanelUser(User $user): static
    {
        return $this->withSession(['two_factor_passed' => true])->actingAs($user->fresh());
    }

    public function test_root_can_set_backup_config(): void
    {
        $root = $this->userWithRole('root');
        $this->asPanelUser($root)->get('/backup-config')
            ->assertOk()
            ->assertSee('Backup config')
            ->assertSee('config.json');

        $this->asPanelUser($root)->post('/backup-config', [
            'schedule' => 'daily',
            'retention' => '14',
        ])->assertRedirect(route('backup-config.index'));

        $row = BackupConfig::query()->first();
        $this->assertNotNull($row);
        $this->assertSame('daily', $row->schedule);
        $this->assertSame(14, (int) $row->retention);
        $task = DB::table('tasks')->where('type', 'backup.config')->first();
        $this->assertNotNull($task);
        $this->assertStringNotContainsString('|', (string) $task->payload);
    }

    public function test_pipe_schedule_is_rejected(): void
    {
        $root = $this->userWithRole('root');
        $this->asPanelUser($root)->post('/backup-config', [
            'schedule' => '|/bin/sh',
            'retention' => '14',
        ])->assertRedirect();
        $this->assertSame(0, BackupConfig::query()->count());
        $this->assertNull(DB::table('tasks')->where('type', 'backup.config')->first());
    }

    public function test_path_escape_retention_is_rejected(): void
    {
        $root = $this->userWithRole('root');
        $this->asPanelUser($root)->post('/backup-config', [
            'schedule' => 'daily',
            'retention' => '../etc',
        ])->assertRedirect();
        $this->assertSame(0, BackupConfig::query()->count());
        $this->assertNull(DB::table('tasks')->where('type', 'backup.config')->first());
    }

    public function test_root_dashboard_has_backup_config_and_create_account(): void
    {
        $root = $this->userWithRole('root');
        $this->asPanelUser($root)->get('/dashboard')
            ->assertOk()
            ->assertSee('Backup Config')
            ->assertSee('Create Account');
    }

    public function test_customer_dashboard_hides_backup_config(): void
    {
        $customer = $this->userWithRole('user');
        $this->asPanelUser($customer)->get('/dashboard')
            ->assertOk()
            ->assertSee('File Restoration')
            ->assertDontSee('Backup Config')
            ->assertDontSee('Create Account');
    }

    public function test_scheduler_state_is_shown_to_the_whm_admin(): void
    {
        $root = $this->userWithRole('root');

        // Nothing configured yet → the card must say so, not pretend backups run.
        $this->asPanelUser($root)->get('/backup-config')
            ->assertOk()
            ->assertSee('Scheduled backups (cron)')
            ->assertSee('backup-schedule.json')
            ->assertSee('disabled');

        BackupConfig::query()->create(['schedule' => 'weekly', 'retention' => 21]);
        $this->asPanelUser($root)->get('/backup-config')
            ->assertOk()
            ->assertSee('Scheduled backups (cron)')
            ->assertSee('weekly')
            ->assertSee('retention 21 days')
            ->assertSee('next run')
            ->assertSee('Backup User Selection rows');
    }

    public function test_customer_and_mail_cannot_open_backup_config(): void
    {
        $customer = $this->userWithRole('user');
        $mail = $this->userWithRole('mail');
        $this->asPanelUser($customer)->get('/backup-config')->assertForbidden();
        $this->asPanelUser($mail)->get('/backup-config')->assertForbidden();
    }
}
